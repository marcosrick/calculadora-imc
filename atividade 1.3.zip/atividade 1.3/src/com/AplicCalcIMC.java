package com;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


class GuiPrincipal extends JFrame{


    private JTextField editapeso;
    private JTextField editaaltura;
    private JButton botcalculo;
    private JLabel lblpeso;
    private JLabel lblaltura;
    private JLabel lblresultado;


    public GuiPrincipal(){

        setConfig();
    }


    private void setConfig() {

        this.setTitle("Calculando seu IMC");
        this.setSize(600, 500);
        this.setLayout(new GridLayout(0, 2));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(new Color(100, 123, 120));



        editapeso=new JTextField();
        editaaltura=new JTextField();
        botcalculo=new JButton("=");
        lblpeso=new JLabel("Informe seu peso:");
        lblaltura=new JLabel("Informe sua altura:");
        lblresultado=new JLabel("Seu IMC =  ");

        botcalculo.addActionListener(new EventoCalculaIMC());

        this.add(lblpeso);
        this.add(lblaltura);
        this.add(editapeso);
        this.add(editaaltura);
        this.add(lblresultado);
        this.add(botcalculo);
    }


    class EventoCalculaIMC implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            try {

                //converter string em double
                double peso=Double.parseDouble(editapeso.getText());
                double altura=Double.parseDouble(editaaltura.getText());

                double imc=peso/Math.pow(altura,2) * 1;

                DecimalFormat df=new DecimalFormat("#0.00");

                String resultado="Seu IMC é: "+df.format(imc);

                if(imc < 17){
                    resultado+=" - Voê está muito abaixo do peso";
                }
                else if(imc < 18.49){
                    resultado+=" - Você está abaixo do peso";
                }
                else if(imc < 24.99){
                    resultado+=" - Parabéns você está no peso normal";
                }
                else if(imc < 29.99){
                    resultado+=" - Cuidado você está acima do peso";
                }
                else if(imc < 34.99){
                    resultado+=" - Cuidado você está com  obesidade grau 1";
                }
                else if(imc < 39.99){
                    resultado+=" - Cuidado você está com  obesidade severa grau 2";
                }
                else
                    resultado+=" - Cuidado você está com  obesidade mórbida grau 3";

                lblresultado.setText(resultado);

            }catch (ArithmeticException ar) {
                JOptionPane.showMessageDialog(null, "Erro aritmético, causa: "+ar.getMessage());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erro desconhecido, causa: "+ex.getMessage());
            }
        }
    }

}

public class AplicCalcIMC {
    public static void main(String[] args) {

        new GuiPrincipal().setVisible(true);
    }
}